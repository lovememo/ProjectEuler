package Problem26_50;

public class Snippet {
	public static void main(String[] args) {
	}
}

