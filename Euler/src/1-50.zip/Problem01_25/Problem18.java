package Problem01_25;

class Node {
	private int value = 0;
	public Node leftChild = null;
	public Node rightChild = null;
	
	public int getValue() {
		return value;
	}
	
	public void setValue(int number) {
		this.value = number;
	}
}

class NumberTree {
	private Node node;

	public NumberTree(int[][] number) {
		int height = number.length;
		int length = (1 + number[height-1].length) * height / 2;
		
		Node[] nodes = new Node[length];
		for(int i=0; i<length; i++) {
			nodes[i] = new Node();
		}
		
		int k = 0;
		for(int i=0; i<height; i++) {
			for(int j=0; j<number[i].length; j++) {	
				nodes[k].setValue(number[i][j]);
				if(i != height-1) {
					int left = k + number[i].length; //��ǰ�ڵ����ż��ϵ�ǰ�еĳ���					
					nodes[k].leftChild = nodes[left];
					nodes[k].rightChild = nodes[left + 1];
				}
				k ++;
			}
		}
		this.node = nodes[0];
	}
	
	public int getMaxPathSum() {
		return this.getMaxPathSum(node);
	}
	
	private int getMaxPathSum(Node node) {
		if(node.leftChild == null) {
			return node.getValue();
		}
		
		int leftValue = node.getValue() + this.getMaxPathSum(node.leftChild);
		int rightValue = node.getValue() + this.getMaxPathSum(node.rightChild);
		return Math.max(leftValue, rightValue);		
	}
	
}


public class Problem18 {
	public static int[][] number = {
		    { 75 }, 
		    { 95, 64 }, 
		    { 17, 47, 82 },
			{ 18, 35, 87, 10 }, 
			{ 20, 4, 82, 47, 65 },
			{ 19, 1, 23, 75, 3, 34 }, 
			{ 88, 2, 77, 73, 7, 63, 67 },
			{ 99, 65, 4, 28, 6, 16, 70, 92 },
			{ 41, 41, 26, 56, 83, 40, 80, 70, 33 },
			{ 41, 48, 72, 33, 47, 32, 37, 16, 94, 29 },
			{ 53, 71, 44, 65, 25, 43, 91, 52, 97, 51, 14 },
			{ 70, 11, 33, 28, 77, 73, 17, 78, 39, 68, 17, 57 },
			{ 91, 71, 52, 38, 17, 14, 91, 43, 58, 50, 27, 29, 48 },
			{ 63, 66, 4, 68, 89, 53, 67, 30, 73, 16, 69, 87, 40, 31 },
			{ 4, 62, 98, 27, 23, 9, 70, 98, 73, 93, 38, 53, 60, 4, 23 }
	};
	
	public static void main(String[] args) {
		NumberTree numberTree =	new NumberTree(number);
		System.out.print(numberTree.getMaxPathSum());
	}

}
